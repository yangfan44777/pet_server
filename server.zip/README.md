PetsServer
==========

#### 启动 mongodb

``` bash
mongod --config /usr/local/etc/mongod.conf
```

#### 启动 node 服务
``` bash
node bin/www
```
